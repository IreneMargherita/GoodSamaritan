$(document).ready(function(){
    $('input[type=password]').keyup(function() {
    }).focus(function() {
        
        $('#pswd_info').show();
    });
});